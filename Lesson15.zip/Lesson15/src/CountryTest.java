import java.util.Scanner;

public class CountryTest {
    public static void main(String[] args) {
        geographyTest();
    }

    public static void geographyTest() {
        String[] countries = {"Uzbekistan", "Turkiya", "Amerika", "Qozog'iston", "Rossiya",
                "Xitoy", "Hindiston", "Arabiston", "Fransiya", "Buyuk Britaniya"};

        String[] currencies = {"so'm", "lira", "dollar", "tenge", "rubl",
                "yuan", "rupiya", "dinor", "frank", "funt sterling"};

        String[] capitals = {"Toshkent", "Anqara", "Vashington", "Nursulton", "Moskva",
                "Pekin", "Dehli", "Ar-Riyod", "Parij", "London"};

        String[] languages = {"uzbek", "turk", "ingliz", "qozoq", "rus",
                "xitoy", "hind", "arab", "fransuz", "ingliz"};

        String[] contients = {"Osiyo", "Osiyo", "Amerika", "Osiyo", "Osiyo",
                "Osiyo", "Osiyo", "Osiyo", "Yevropa", "Yevropa"};


        int sum = 0;
        int gameOn = 1;
        int count=0;
        while (gameOn == 1) {
            int ran = (int) (Math.random() * 10);
            int win = 0;
            Scanner scanner = new Scanner(System.in);
            System.out.println((++count)+" - o'yin");
            System.out.print(countries[ran] + " davlatining poytaxtini toping: ");
            if (scanner.nextLine().equals(capitals[ran])) {
                win = 100;
                System.out.println("tabriklaymiz topdingiz va 100 ball oldingiz");
            }

            if (win == 0) {
                System.out.print("Topolmadingiz. Pul birligini toping: ");
                if (scanner.nextLine().equals(currencies[ran])) {
                    win = 75;
                    System.out.println("tabriklaymiz topdingiz va 75 ball oldingiz");
                }
            }
            if (win == 0) {
                System.out.print("Topolmadingiz. Davlat tilini toping: ");
                if (scanner.nextLine().equals(languages[ran])) {
                    win = 50;
                    System.out.println("tabriklaymiz topdingiz va 50 ball oldingiz");
                }
            }
            if (win == 0) {
                System.out.print("Topolmadingiz. Davlat joylashgan qit'ani toping: ");
                if (scanner.nextLine().equals(contients[ran])) {
                    win = 25;
                    System.out.println("tabriklaymiz topdingiz va 25 ball oldingiz");
                } else {
                    System.out.println("shuni ham topolmadingizmi ?!!");
                }
            }

            sum += win;

            System.out.println("Sizning umumiy balingiz: " + sum);
            System.out.println("Sizning o'rtacha balingiz: "+sum/count);

            System.out.println("\nstart => 1 , exit => 0");
            gameOn = scanner.nextInt();
        }
    }

}
