import java.util.Scanner;

public class BuyCar {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        String[] cars = {"damas", "spark", "cobalt", "nexia-3", "lacetti", "tracker", "malibu-2", "captiva"};
        double[] price = {78000000, 94000000, 108000000, 89000000, 136000000, 189000000, 324000000, 260000000};

        for (int i = 0; i < cars.length; i++) {
            System.out.print(i + 1 + " - " + cars[i] + ", ");
        }
        System.out.print("\nAvtomobil rusumini tanlang (raqamlar orqali) : ");
        int carNum = scanner.nextInt();
        if (carNum < 1 || carNum > 8) {
            System.out.println("Mashina raqami to'g'ri tanlanmadi");
            return;
        }
        System.out.printf(cars[carNum - 1] + " rusumli mashinasining narxi -  %.2f", price[carNum - 1]);

        System.out.print("\nNecha foizini oldindan to'lamoqchisiz: ");
        double startPer = scanner.nextDouble();
        int year=0;
        if (startPer<100){
            System.out.print("qolgan qismini necha yilda to'laysiz: ");
            year = scanner.nextInt();
            if (year > 3) {
                System.out.println("Maksimal 3 yilga to'lash sharti bilan beriladi !!!");
                return;
            }
        }else if (startPer>100){
            System.out.println("Ortiqcha to'lab Yuboryapsiz");
            return;
        }

        double month = month(price[carNum - 1], startPer, year);

        System.out.println("Xarid ma'lumotlari:");
        System.out.println("Model: " + cars[carNum - 1]);
        System.out.printf("Narxi: %.2f so'm", price[carNum - 1]);
        System.out.printf("\nBoshlang'ich to'lov: %.2f so'm", price[carNum - 1] * startPer / 100);
        System.out.println(" ( " + startPer + " % )");
        System.out.printf("Kredit miqdori: %.2f so'm", price[carNum - 1] * (1 - startPer / 100));
        System.out.println("\nKredit muddati: " + year + " yil");
        System.out.println("Yillik foiz: " + percent(startPer, year) * 100 + " \u0025");
        System.out.printf("Oylik to'lov: %.2f so'm", month);

        System.out.println("\n1 - accept, 0 - deny");
        int accept = scanner.nextInt();
        if (accept == 1) {
            System.out.println("Xaridingiz uchun raxmat");
        } else {
            System.out.println("Foydalanuvchi shartlari bajarilmadi");
        }

    }

    public static double percent(double startPay, int year) {
        double percent = 0;
        if (startPay <= 15) {
            switch (year) {
                case 1:
                    percent = 0.16;
                    break;
                case 2:
                    percent = 0.22;
                    break;
                case 3:
                    percent = 0.26;
                    break;
            }
        } else if (startPay <= 30) {
            switch (year) {
                case 1:
                    percent = 0.13;
                    break;
                case 2:
                    percent = 0.18;
                    break;
                case 3:
                    percent = 0.22;
                    break;
            }
        } else if (startPay <= 50) {
            switch (year) {
                case 1:
                    percent = 0.10;
                    break;
                case 2:
                    percent = 0.16;
                    break;
                case 3:
                    percent = 0.18;
                    break;
            }
        } else if (startPay <= 80) {
            switch (year) {
                case 1:
                    percent = 0.08;
                    break;
                case 2:
                    percent = 0.12;
                    break;
                case 3:
                    percent = 0.15;
                    break;
            }
        }
        return percent;
    }

    public static double month(double price, double startPay, int year) {
        double percent = percent(startPay, year);
        return (1 - startPay / 100) * price * Math.pow(1 + percent, year) / (year * 12);
    }

}