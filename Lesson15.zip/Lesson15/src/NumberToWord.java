import java.util.Scanner;

public class NumberToWord {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Butun son kiriting(15 xonagacha): ");
        String res = "";
        long number = scanner.nextLong();
        if (number == 0) {
            res += "nol";
        } else if (number < 0) {
            number *= -1;
            res += "minus ";
        }

        res = res + plural(number);
        System.out.println(res);
        main(args);
    }

    public static String hundreds(int num) {

        String res = "";
        String[] singular = {"", "bir ", "ikki ", "uch ", "to'rt ", "besh ",
                "olti ", "yetti ", "sakkiz ", "to'qqiz "};
        String[] decimal = {"", "o'n ", "yigirma ", "o'ttiz ", "qirq ", "ellik ",
                "oltmish ", "yetmish ", "sakson ", "to'qson "};

        int a1 = num % 10;
        int a2 = num / 10 % 10;
        int a3 = num / 100;

        if (a3 != 0) {
            res = res + singular[a3] + "yuz ";
        }
        return res + decimal[a2] + singular[a1];
    }

    public static String plural(long number) {

        String[] thousand = {"", "ming ", "million ", "milliyard ", "trillion "};
        String res = "";
        int residue;               //qoldiq
        int count = 0;
        String temp;

        while (number != 0) {

            residue = (int) (number % 1000);          //qoldiq
            number = number / 1000;
            temp = hundreds(residue);

            if (temp.length() != 0) {
                temp = temp + thousand[count];
            }

            res = temp.concat(res);
            count++;
        }

        return res;
    }
}
